
import { useState } from "react";
import { Item } from "./ProjectCostTracker";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

type AddItemFormProps = {
  item?: Item;
  onSubmit: (item: Item | Omit<Item, "id">) => void;
  onCancel: () => void;
};

export function AddItemForm({ item, onSubmit, onCancel }: AddItemFormProps) {
  const [name, setName] = useState(item?.name || "");
  const [cost, setCost] = useState(item?.cost.toString() || "");
  const [errors, setErrors] = useState({ name: "", cost: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const newErrors = { name: "", cost: "" };
    let hasError = false;
    
    if (!name.trim()) {
      newErrors.name = "Name is required";
      hasError = true;
    }
    
    if (!cost.trim()) {
      newErrors.cost = "Cost is required";
      hasError = true;
    } else if (isNaN(Number(cost)) || Number(cost) < 0) {
      newErrors.cost = "Cost must be a positive number";
      hasError = true;
    }
    
    if (hasError) {
      setErrors(newErrors);
      return;
    }
    
    // Submit the form
    if (item) {
      onSubmit({ ...item, name, cost: Number(cost) });
    } else {
      onSubmit({ name, cost: Number(cost) });
    }
  };

  return (
    <Card className="border shadow-sm bg-white">
      <CardHeader className="pb-3 bg-blue-50">
        <CardTitle className="text-lg text-blue-700">
          {item ? "Edit Item" : "Add New Item"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-gray-700">Item Name</Label>
            <Input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Laptop, Software License"
              className="focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            />
            {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="cost" className="text-gray-700">Cost ($)</Label>
            <Input
              id="cost"
              type="number"
              min="0"
              step="0.01"
              value={cost}
              onChange={(e) => setCost(e.target.value)}
              placeholder="0.00"
              className="focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            />
            {errors.cost && <p className="text-sm text-red-500">{errors.cost}</p>}
          </div>
          
          <div className="flex justify-end space-x-2 pt-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              {item ? "Update" : "Add"} Item
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
