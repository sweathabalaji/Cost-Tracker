
import { useState } from "react";
import { OtherCost } from "./ProjectCostTracker";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

type AddOtherCostFormProps = {
  otherCost?: OtherCost;
  onSubmit: (cost: OtherCost | Omit<OtherCost, "id">) => void;
  onCancel: () => void;
};

export function AddOtherCostForm({ otherCost, onSubmit, onCancel }: AddOtherCostFormProps) {
  const [description, setDescription] = useState(otherCost?.description || "");
  const [amount, setAmount] = useState(otherCost?.amount.toString() || "");
  const [errors, setErrors] = useState({ description: "", amount: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const newErrors = { description: "", amount: "" };
    let hasError = false;
    
    if (!description.trim()) {
      newErrors.description = "Description is required";
      hasError = true;
    }
    
    if (!amount.trim()) {
      newErrors.amount = "Amount is required";
      hasError = true;
    } else if (isNaN(Number(amount)) || Number(amount) < 0) {
      newErrors.amount = "Amount must be a positive number";
      hasError = true;
    }
    
    if (hasError) {
      setErrors(newErrors);
      return;
    }
    
    // Submit the form
    if (otherCost) {
      onSubmit({ ...otherCost, description, amount: Number(amount) });
    } else {
      onSubmit({ description, amount: Number(amount) });
    }
  };

  return (
    <Card className="border shadow-sm bg-white">
      <CardHeader className="pb-3 bg-purple-50">
        <CardTitle className="text-lg text-purple-700">
          {otherCost ? "Edit Cost" : "Add Other Cost"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-700">Description</Label>
            <Input
              id="description"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Shipping, Taxes, Installation"
              className="focus:border-purple-300 focus:ring focus:ring-purple-200 focus:ring-opacity-50"
            />
            {errors.description && <p className="text-sm text-red-500">{errors.description}</p>}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-gray-700">Amount ($)</Label>
            <Input
              id="amount"
              type="number"
              min="0"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="focus:border-purple-300 focus:ring focus:ring-purple-200 focus:ring-opacity-50"
            />
            {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
          </div>
          
          <div className="flex justify-end space-x-2 pt-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
              {otherCost ? "Update" : "Add"} Cost
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
