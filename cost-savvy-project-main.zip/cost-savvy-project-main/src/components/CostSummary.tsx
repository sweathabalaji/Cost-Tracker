
import { Badge } from "./ui/badge";
import { Sparkles } from "lucide-react";

type CostSummaryProps = {
  itemCost: number;
  otherCost: number;
  totalCost: number;
};

export function CostSummary({ itemCost, otherCost, totalCost }: CostSummaryProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
      <div className="rounded-lg border shadow-sm hover:shadow-md transition-shadow p-6 bg-white">
        <div className="flex justify-center items-center gap-2 mb-2">
          <h3 className="text-sm font-medium text-gray-500">Items Total</h3>
          <Badge variant="outline" className="bg-blue-50">Items</Badge>
        </div>
        <p className="text-2xl font-bold text-blue-600">${itemCost.toFixed(2)}</p>
      </div>
      
      <div className="rounded-lg border shadow-sm hover:shadow-md transition-shadow p-6 bg-white">
        <div className="flex justify-center items-center gap-2 mb-2">
          <h3 className="text-sm font-medium text-gray-500">Other Costs</h3>
          <Badge variant="outline" className="bg-purple-50">Fees</Badge>
        </div>
        <p className="text-2xl font-bold text-purple-600">${otherCost.toFixed(2)}</p>
      </div>
      
      <div className="rounded-lg shadow-md hover:shadow-lg transition-shadow bg-gradient-to-r from-primary to-blue-600 p-6 text-white">
        <div className="flex justify-center items-center gap-2 mb-2">
          <h3 className="text-sm font-medium">Total Project Cost</h3>
          <Sparkles className="h-4 w-4" />
        </div>
        <p className="text-3xl font-bold">${totalCost.toFixed(2)}</p>
      </div>
    </div>
  );
}
