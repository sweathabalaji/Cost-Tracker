
import { Item } from "./ProjectCostTracker";
import { Button } from "./ui/button";
import { Edit, Trash2 } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";

type ItemListProps = {
  items: Item[];
  onEdit: (item: Item) => void;
  onDelete: (id: string) => void;
};

export function ItemList({ items, onEdit, onDelete }: ItemListProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-12 px-4 border-2 border-dashed border-gray-200 rounded-lg bg-gray-50">
        <p className="text-gray-500">No items added yet.</p>
        <p className="text-sm text-gray-400 mt-1">Add an item to track project costs</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[400px] rounded-lg border shadow-sm bg-white">
      <div className="p-4">
        <div className="grid grid-cols-12 font-medium text-sm text-gray-500 mb-3 px-4 bg-gray-50 py-2 rounded">
          <div className="col-span-5">Name</div>
          <div className="col-span-4">Cost</div>
          <div className="col-span-3">Actions</div>
        </div>
        
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="grid grid-cols-12 items-center p-4 rounded-lg hover:bg-blue-50 border transition-colors"
            >
              <div className="col-span-5 font-medium">{item.name}</div>
              <div className="col-span-4 text-blue-600 font-medium">${item.cost.toFixed(2)}</div>
              <div className="col-span-3 flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit(item)}
                  className="border-blue-200 hover:bg-blue-100 hover:text-blue-700"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDelete(item.id)}
                  className="border-red-200 hover:bg-red-100 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </ScrollArea>
  );
}
