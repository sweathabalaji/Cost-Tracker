
import { OtherCost } from "./ProjectCostTracker";
import { Button } from "./ui/button";
import { Edit, Trash2 } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";

type OtherCostsListProps = {
  otherCosts: OtherCost[];
  onEdit: (cost: OtherCost) => void;
  onDelete: (id: string) => void;
};

export function OtherCostsList({ otherCosts, onEdit, onDelete }: OtherCostsListProps) {
  if (otherCosts.length === 0) {
    return (
      <div className="text-center py-12 px-4 border-2 border-dashed border-gray-200 rounded-lg bg-gray-50">
        <p className="text-gray-500">No other costs added yet.</p>
        <p className="text-sm text-gray-400 mt-1">Add other costs like shipping, taxes, etc.</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[400px] rounded-lg border shadow-sm bg-white">
      <div className="p-4">
        <div className="grid grid-cols-12 font-medium text-sm text-gray-500 mb-3 px-4 bg-gray-50 py-2 rounded">
          <div className="col-span-5">Description</div>
          <div className="col-span-4">Amount</div>
          <div className="col-span-3">Actions</div>
        </div>
        
        <div className="space-y-3">
          {otherCosts.map((cost) => (
            <div
              key={cost.id}
              className="grid grid-cols-12 items-center p-4 rounded-lg hover:bg-purple-50 border transition-colors"
            >
              <div className="col-span-5 font-medium">{cost.description}</div>
              <div className="col-span-4 text-purple-600 font-medium">${cost.amount.toFixed(2)}</div>
              <div className="col-span-3 flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit(cost)}
                  className="border-purple-200 hover:bg-purple-100 hover:text-purple-700"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDelete(cost.id)}
                  className="border-red-200 hover:bg-red-100 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </ScrollArea>
  );
}
