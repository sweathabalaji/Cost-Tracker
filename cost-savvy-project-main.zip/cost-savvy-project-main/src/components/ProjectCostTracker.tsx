
import { useState } from "react";
import { ItemList } from "./ItemList";
import { OtherCostsList } from "./OtherCostsList";
import { AddItemForm } from "./AddItemForm";
import { AddOtherCostForm } from "./AddOtherCostForm";
import { CostSummary } from "./CostSummary";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "./ui/card";
import { PlusCircle } from "lucide-react";

export type Item = {
  id: string;
  name: string;
  cost: number;
};

export type OtherCost = {
  id: string;
  description: string;
  amount: number;
};

export function ProjectCostTracker() {
  const [items, setItems] = useState<Item[]>([]);
  const [otherCosts, setOtherCosts] = useState<OtherCost[]>([]);
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [isAddingOtherCost, setIsAddingOtherCost] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [editingOtherCost, setEditingOtherCost] = useState<OtherCost | null>(null);

  const addItem = (item: Omit<Item, "id">) => {
    const newItem = {
      ...item,
      id: Math.random().toString(36).substring(2, 9),
    };
    setItems([...items, newItem]);
    setIsAddingItem(false);
  };

  const updateItem = (updatedItem: Item) => {
    setItems(items.map((item) => (item.id === updatedItem.id ? updatedItem : item)));
    setEditingItem(null);
  };

  const deleteItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const addOtherCost = (cost: Omit<OtherCost, "id">) => {
    const newCost = {
      ...cost,
      id: Math.random().toString(36).substring(2, 9),
    };
    setOtherCosts([...otherCosts, newCost]);
    setIsAddingOtherCost(false);
  };

  const updateOtherCost = (updatedCost: OtherCost) => {
    setOtherCosts(otherCosts.map((cost) => (cost.id === updatedCost.id ? updatedCost : cost)));
    setEditingOtherCost(null);
  };

  const deleteOtherCost = (id: string) => {
    setOtherCosts(otherCosts.filter((cost) => cost.id !== id));
  };

  const totalItemCost = items.reduce((acc, item) => acc + item.cost, 0);
  const totalOtherCost = otherCosts.reduce((acc, cost) => acc + cost.amount, 0);
  const totalCost = totalItemCost + totalOtherCost;

  return (
    <Card className="border-0 shadow-lg overflow-hidden">
      <CardContent className="p-0">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6">
          <CostSummary 
            itemCost={totalItemCost}
            otherCost={totalOtherCost}
            totalCost={totalCost}
          />
        </div>
        
        <Separator className="my-0" />
        
        <div className="p-6">
          <Tabs defaultValue="items" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="items" className="text-sm font-medium">Project Items</TabsTrigger>
              <TabsTrigger value="other-costs" className="text-sm font-medium">Additional Costs</TabsTrigger>
            </TabsList>
            
            <TabsContent value="items" className="space-y-4 pt-2">
              {isAddingItem ? (
                <AddItemForm 
                  onSubmit={addItem} 
                  onCancel={() => setIsAddingItem(false)} 
                />
              ) : editingItem ? (
                <AddItemForm 
                  item={editingItem} 
                  onSubmit={updateItem} 
                  onCancel={() => setEditingItem(null)} 
                />
              ) : (
                <Button 
                  onClick={() => setIsAddingItem(true)} 
                  className="mb-4 bg-blue-600 hover:bg-blue-700"
                >
                  <PlusCircle className="mr-2 h-4 w-4" /> Add New Item
                </Button>
              )}
              
              <ItemList 
                items={items} 
                onEdit={setEditingItem} 
                onDelete={deleteItem} 
              />
            </TabsContent>
            
            <TabsContent value="other-costs" className="space-y-4 pt-2">
              {isAddingOtherCost ? (
                <AddOtherCostForm 
                  onSubmit={addOtherCost} 
                  onCancel={() => setIsAddingOtherCost(false)} 
                />
              ) : editingOtherCost ? (
                <AddOtherCostForm 
                  otherCost={editingOtherCost} 
                  onSubmit={updateOtherCost} 
                  onCancel={() => setEditingOtherCost(null)} 
                />
              ) : (
                <Button 
                  onClick={() => setIsAddingOtherCost(true)} 
                  className="mb-4 bg-purple-600 hover:bg-purple-700"
                >
                  <PlusCircle className="mr-2 h-4 w-4" /> Add Other Cost
                </Button>
              )}
              
              <OtherCostsList 
                otherCosts={otherCosts} 
                onEdit={setEditingOtherCost} 
                onDelete={deleteOtherCost} 
              />
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
}
