
import { useState } from "react";
import { ProjectCostTracker } from "@/components/ProjectCostTracker";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-blue-50">
      <div className="container mx-auto py-12">
        <h1 className="text-4xl font-bold text-center mb-2 text-primary">Project Cost Tracker</h1>
        <p className="text-center text-gray-500 mb-10">Track and manage your project expenses efficiently</p>
        <ProjectCostTracker />
      </div>
    </div>
  );
};

export default Index;
